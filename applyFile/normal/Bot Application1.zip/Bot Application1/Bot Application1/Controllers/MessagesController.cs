﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using Bot_Application1.Models;

namespace Bot_Application1
{
    [BotAuthentication]
    public class MessagesController : ApiController
    {
        RX178 rx178 = new RX178();

        static async Task<RX78> MakeRX78Request(string queryString)
        {
            var client = new HttpClient();
            var mySer = new JavaScriptSerializer();
            RX78 rx78_instance = new RX78();
            try
            {
                string uri = "https://api.projectoxford.ai/luis/v1/application?id=1d1031b1-eaaa-4597-9f1a-a6bbe723972b&subscription-key=0841f85eed9840238fdd51d1c40d5234&q=" + queryString;

                string response = await client.GetStringAsync(uri);
                rx78_instance = mySer.Deserialize<RX78>(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            return rx78_instance;
        }


        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// </summary>
        /// 
        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            if (activity.Type == ActivityTypes.Message)
            {
                ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
                // calculate something for us to return
                int length = (activity.Text ?? string.Empty).Length;

                //CjpTTS.TTS.Speak(activity.Text);
                // return our reply to the user

                var rx78 = await MakeRX78Request(activity.Text);
                string replyString = $"You sent {activity.Text} which was {length} characters\nDetect result:\n{rx78.ToString()}";
                Activity reply = activity.CreateReply(replyString);

                var mReply = rx178.GetVirtualData(rx78.intents[0].intent);

                if (rx78.intents[0].intent == "出行")
                {
                    bool flag = false;
                    foreach (var e in rx78.entities)
                    {
                        if (e.type == "位置")
                        {
                            flag = true;
                            mReply = String.Format(mReply, "到" + e.entity + "去");
                            break;
                        }
                    }
                    if (!flag)
                        mReply = String.Format(mReply, "出去");
                }
                CjpTTS.TTS.Speak(mReply);
                //Activity reply = activity.CreateReply($"You sent {activity.Text} which was {length} characters");
                await connector.Conversations.ReplyToActivityAsync(reply);
            }
            else
            {
                HandleSystemMessage(activity);
            }
            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        private Activity HandleSystemMessage(Activity message)
        {
            if (message.Type == ActivityTypes.DeleteUserData)
            {
                // Implement user deletion here
                // If we handle user deletion, return a real message
            }
            else if (message.Type == ActivityTypes.ConversationUpdate)
            {
                // Handle conversation state changes, like members being added and removed
                // Use Activity.MembersAdded and Activity.MembersRemoved and Activity.Action for info
                // Not available in all channels
            }
            else if (message.Type == ActivityTypes.ContactRelationUpdate)
            {
                // Handle add/remove from contact lists
                // Activity.From + Activity.Action represent what happened
            }
            else if (message.Type == ActivityTypes.Typing)
            {
                // Handle knowing tha the user is typing
            }
            else if (message.Type == ActivityTypes.Ping)
            {
            }

            return null;
        }
    }
}