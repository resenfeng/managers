﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bot_Application1.Models
{
    public class RX178
    {
        public Dictionary<string, string> kvData = new Dictionary<string, string>();
        
        public RX178()
        {
            kvData.Add("进食", "爸妈，快看这是我最近自己在刷美食呢！");
            kvData.Add("生病", "爸妈，最近我生病了，求抱抱。");
            kvData.Add("抒情", "爸妈，最近我过得非常好");
            kvData.Add("运动", "爸妈，最近你我天天运动，快看这张照片");
            kvData.Add("秀恩爱", "爸妈，喜事降临啊，孩子不久就要给你抱孙子啦。");
            kvData.Add("推广", "爸妈，最近我过得非常平安。公众号还挺顺利");
            kvData.Add("学习", "爸妈，最近我非常爱学习，一代拼神！");
            kvData.Add("追星", "爸妈，我最近看上了一个特别好看的明星");
            kvData.Add("激励", "爸妈，我会继续加油的。");
            kvData.Add("吐槽", "爸妈，最近我过得非常平安。");
            kvData.Add("红包", "爸妈，最近我最近挺壕的，去抢他们红包吧");
            kvData.Add("出行", "爸妈，最近我又{0}玩了啊，特别开心你看！");
            kvData.Add("八卦新闻", "爸妈，我们来聊一聊八卦吧。");
            kvData.Add("晒照片", "爸妈，快看我最近的动态。");
            kvData.Add("None", "爸妈，最近我过得非常平安。");
        }

        public string GetVirtualData(string s)
        {
            return kvData[s];
        }
    }
}