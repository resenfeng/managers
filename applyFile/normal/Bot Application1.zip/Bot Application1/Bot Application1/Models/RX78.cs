﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bot_Application1.Models
{
    [Serializable]
    public class RX78
    {
        public class RX78_intentCls
        {
            //目的
            public string intent;
            //分数
            public double score;
        }

        public class RX78_entitiesCls
        {
            public string entity;
            public string type;
            public int startIndex;
            public int endIndex;
            public double score;
        }
        //查询的内容
        public string query;
        public RX78_intentCls[] intents;
        public RX78_entitiesCls[] entities;

        public override string ToString()
        {
            var result = "Query: " + query + '\n';
            result += "Intent: " + intents[0].intent + '\n';

            int i = 0;
            foreach (var e in entities)
            {
                result += String.Format("\nEntity {0}\n", i++);
                result += String.Format("\'{0}\' = \'{1}\'", e.type, e.entity);
            }

            return result;
        }
    }
}
